package com.example.OTP.Varication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OtpVaricationApplicationTests {

	@Test
	void contextLoads() {
	}

}
