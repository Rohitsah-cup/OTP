package com.example.OTP.Varication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtpVaricationApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtpVaricationApplication.class, args);
	}

}
